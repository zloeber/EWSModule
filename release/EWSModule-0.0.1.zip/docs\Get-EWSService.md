---
external help file: EWSModule-help.xml
online version: http://www.the-little-things.net/
schema: 2.0.0
---

# Get-EWSService

## SYNOPSIS
Returns the current EWSService module variable object

## SYNTAX

```
Get-EWSService
```

## DESCRIPTION
Returns the current EWSService module variable object

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Get-EWSService
```

Description
--------------
Returns the current EWSService module variable object

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES
Author: Zachary Loeber
Site: http://www.the-little-things.net/
Requires: Powershell 3.0
Version History
1.0.0 - Initial release

## RELATED LINKS

